Dont spam click buttons as this app changes around files and may make a mistake if spammed

For how to use this app / the full readme go to ---> https://github.com/AaaaaaICO/DUMH-Mod-Manager

Please message me through github if you find a bug or a QOL change you want added

Thx for downloading.

-- AICO



[gamebanana] Go to the github if you want the .console file(for error checks) ---> https://github.com/AaaaaaICO/DUMH-Mod-Manager/releases/tag/v1.0-beta


THIS APP IS STILL IN BETA AND WILL CONTAIN ISSUES